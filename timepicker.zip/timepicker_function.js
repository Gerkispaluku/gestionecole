var TimePicker = {

	FieldEdit_Suffix: function(ctl, ctlid) {

		var sWrk = "";

		var bFldHidden;
		var bUserTable = ew_HasUserTable();
		var bUserID = (bUserTable && ew_IsNotEmpty(DB.SecuUserIDFld));
		var bTableHasUserIDFld = (bUserID && ew_IsNotEmpty(TABLE.TblUserIDFld));
		var bFldHasDefaultValue = (ew_IsNotEmpty(goFld.FldDefault) || (bTableHasUserIDFld && TABLE.TblUserIDFld == goFld.FldName));
		if ((ctlid == "add" && bFldHasDefaultValue) ||
			ctlid == "edit") {
			bFldHidden = true;
		} else {
			bFldHidden = false;
		}

		if ((goFld.FldHtmlTag == "TEXT" || (goFld.FldHtmlTag == "HIDDEN" && !bFldHidden)) && goFld.FldPopCalendar &&
			(goFld.FldValidate == "TIME" || goFld.FldDtFormat == 3 || goFld.FldDtFormat == 4)) {

			var sTimeFormat, iStep, sOptions;

			var EXT_FIELD = ew_GetExtFld("TimePicker", TABLE.TblName, goFld.FldName);
			if (EXT_FIELD) {
				sTimeFormat = ew_GetExtPrp(EXT_FIELD.Properties, "TimeFormat");
				iStep = ew_GetExtPrp(EXT_FIELD.Properties, "Step");
				sOptions = ew_GetExtPrp(EXT_FIELD.Properties, "Options");
			}

			var options = (sOptions) ? JSON.parse(sOptions) : {};
			options["timeFormat"] = (sTimeFormat) ? sTimeFormat : "H:i:s";
			if (iStep > 0) options["step"] = iStep;

			var formid = ew_FormObj(ctlid);
			var sFldObj = TABLE.TblVar + "->" + goFld.FldParm;
			sWrk += "<?php if (!$" + sFldObj + "->ReadOnly && !$" + sFldObj + "->Disabled && !isset($" + sFldObj + "->EditAttrs[\"readonly\"]) && !isset($" + sFldObj + "->EditAttrs[\"disabled\"])) { ?>\r\n";
			sWrk += '<script type="text/javascript">' +
				'ew_CreateTimePicker("' + formid + '", "' + ctl + '", ' + JSON.stringify(options).replace(sTimeFormat, sTimeFormat.replace(/:/g, '" + EW_TIME_SEPARATOR + "')) + ');' +
				'</script>';
			sWrk += "<?php } ?>\r\n";

		}

		return sWrk;

	}

}
global.TimePicker = TimePicker; // Global to all modules