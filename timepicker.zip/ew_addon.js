<!--##session timepicker_inc##-->
<!--##
	if (bUseTimePicker) {
##-->
<link href="<?php echo $EW_RELATIVE_PATH ?>timepicker/jquery.timepicker.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<?php echo $EW_RELATIVE_PATH ?>timepicker/jquery.timepicker.min.js"></script>
<script type="text/javascript" src="<?php echo $EW_RELATIVE_PATH ?><!--##=ew_GetFileNameByCtrlID("ewtimepicker.js")##-->"></script>
<!--##
	}
##-->
<!--##/session##-->