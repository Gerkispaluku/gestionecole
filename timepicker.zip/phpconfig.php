<!--##session timepicker_config##-->
<!--##
	// Check if use time picker
	var bUseTimePicker = false;
	var EXT = ew_GetExtObj("TimePicker");
	if (EXT && EXT.Enabled) {
		for (var i = 0, len = DB.Tables.length; i < len; i++) {
			var TMPTABLE = DB.Tables[i];
			for (var j = 0, fldlen = TMPTABLE.Fields.length; j < fldlen; j++) {
				var f = TMPTABLE.Fields[j];
				if (f.FldPopCalendar && (f.FldValidate == "TIME" || f.FldDtFormat == 3 || f.FldDtFormat == 4)) {
					bUseTimePicker = true;
					break;
				}
			}
		}
	}
##-->
<!--##/session##-->
