<!--##session menu_config##-->
<!--##
	sBrand = "";
	sBrandHref = "";
	var bInverted = false;
	var sExtName = "HorizontalMenu";
	var EXT = ew_GetExtObj(sExtName);
	if (EXT.Enabled && EXT.PROJ) {
		var sBrandWrk = ew_GetExtPrp(EXT.PROJ.Properties, "Brand");
		if (ew_IsNotEmpty(sBrandWrk))
			sBrand = sBrandWrk;
		var sBrandHrefWrk = ew_GetExtPrp(EXT.PROJ.Properties, "BrandHref");
		if (ew_IsNotEmpty(sBrandHrefWrk))
			sBrandHref = sBrandHrefWrk;
		var bInvertedWrk = ew_GetExtPrp(EXT.PROJ.Properties, "Inverted");
		if (ew_IsNotEmpty(bInvertedWrk))
			bInverted = bInvertedWrk;
	}
##-->
<!--##/session##-->
