<!--##session menu##-->
	<div id="ewMenuRow"<?php if (ew_IsResponsiveLayout()) { ?> class="hidden-xs"<?php } ?>>
		<div class="ewMenu">
<!--##=SYSTEMFUNCTIONS.IncludeFile("menu","")##-->
		</div>
	</div>
	<!-- content (begin) -->
	<div id="ewContentTable" class="ewContentTable">
		<div id="ewContentRow">
<!--##/session##-->	
