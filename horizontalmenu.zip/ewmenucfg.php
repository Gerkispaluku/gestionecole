<!--##session ewconfigmenu##-->
<?php
// Menu
define("EW_MENUBAR_ID", "ewHorizMenu", TRUE);
define("EW_MENUBAR_BRAND", "<!--##=ew_Quote(sBrand)##-->", TRUE);
define("EW_MENUBAR_BRAND_HYPERLINK", "<!--##=ew_Quote(sBrandHref)##-->", TRUE);
<!--## if (bInverted) { ##-->
define("EW_MENUBAR_CLASSNAME", "navbar navbar-inverse", TRUE);
<!--## } else { ##-->
define("EW_MENUBAR_CLASSNAME", "navbar navbar-default", TRUE);
<!--## } ##-->
define("EW_MENUBAR_INNER_CLASSNAME", "", TRUE);
define("EW_MENU_CLASSNAME", "nav navbar-nav", TRUE);
define("EW_SUBMENU_CLASSNAME", "dropdown-menu", TRUE);
define("EW_SUBMENU_DROPDOWN_IMAGE", " <b class=\"caret\"></b>", TRUE);
define("EW_SUBMENU_DROPDOWN_ICON_CLASSNAME", "", TRUE);
//define("EW_MENU_DIVIDER_CLASSNAME", "divider-vertical", TRUE);
define("EW_MENU_DIVIDER_CLASSNAME", "divider", TRUE);
define("EW_MENU_ITEM_CLASSNAME", "dropdown", TRUE);
define("EW_SUBMENU_ITEM_CLASSNAME", "dropdown-submenu", TRUE);
define("EW_MENU_ACTIVE_ITEM_CLASS", "active", TRUE);
define("EW_SUBMENU_ACTIVE_ITEM_CLASS", "active", TRUE);
define("EW_MENU_ROOT_GROUP_TITLE_AS_SUBMENU", TRUE, TRUE);
define("EW_SHOW_RIGHT_MENU", TRUE, TRUE);
?>
<!--##/session##-->