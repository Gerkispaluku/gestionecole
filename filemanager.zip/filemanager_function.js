var FCKeditor = {}
global.FCKeditor = FCKeditor; // Global to all modules