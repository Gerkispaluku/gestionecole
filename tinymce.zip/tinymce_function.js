var TinyMCE = {

	FieldEdit_Suffix: function(ctl, ctlid) {
	
		var sWrk = "";

		var sFldHtmlTag = FIELD.FldHtmlTag;
		if ((ctlid == "search" || ctlid == "extbs") && sFldHtmlTag == "TEXTAREA" && PROJ.GetV("ReplaceTextAreaByText"))
			sFldHtmlTag = "TEXT";

		if (sFldHtmlTag == "TEXTAREA" && FIELD.FldUseDHTMLEditor) {
			sWrk += "<script type=\"text/javascript\">" + "\r\n";
			sWrk += "ew_CreateEditor(\"" + ew_FormObj(ctlid) + "\", \"" + ctl + "\", " + FIELD.FldTagCols + ", " + FIELD.FldTagRows + ", <?php echo ($" + TABLE.TblVar + "->" + FIELD.FldParm + "->ReadOnly || " + ew_Val(FIELD.FldHtmlTagReadOnly && ctlid == "edit") + ") ? \"true\" : \"false\" ?>);" + "\r\n";
			sWrk += "</script>" + "\r\n";
		}

		return sWrk;

	}

}
global.TinyMCE = TinyMCE; // Global to all modules

global.bUseTinyMCE = false; // Global to all modules

function UseTinyMCE() {
	return bUseTinyMCE;
}
global.UseTinyMCE = UseTinyMCE; // Global to all modules

// Set up bUseTinyMCE
(function() {
	var EXT = ew_GetExtObj("TinyMCE");
	if (EXT && EXT.Enabled) {
		for (var i = 0, len = DB.Tables.length; i < len; i++) {
			var TMPTABLE = DB.Tables[i];
			for (var j = 0, fldlen = TMPTABLE.Fields.length; j < fldlen; j++) {
				if (TMPTABLE.Fields[j].FldUseDHTMLEditor) {
					bUseTinyMCE = true;
					break;
				}
			}
		}
	}
})();