<?php
<!--##session report_word_link##-->
		$this->ExportWordUrl = str_replace("&amp;custom=1", "", $this->ExportWordUrl); // Do not support custom template
		$item =& $this->ExportOptions->GetItem("word");
<!--## if (bUseEmbeddedImagesForEmail) { ##-->
		$exportid = session_id();
		$item->Body = "<a data-caption=\"" . ewr_HtmlEncode($ReportLanguage->Phrase("ExportToWordText")) . "\" href=\"javascript:void(0);\" onclick=\"ewr_ExportCharts(this, '" . $this->ExportWordUrl . "','" . $exportid . "');\">" . <!--##=sExportToWordCaption##--> . "</a>";
<!--## } else { ##-->
		$item->Body = "<a data-caption=\"" . ewr_HtmlEncode($ReportLanguage->Phrase("ExportToWordText")) . "\" href=\"" . $this->ExportWordUrl . "\">" . <!--##=sExportToWordCaption##--> . "</a>";
<!--## } ##-->
<!--##/session##-->
?>


<?php
<!--##session report_word_function##-->
<!--##
	var iColumnWidth = 0;
	var iRowHeight = 0;
	var sExtName = "PHPWord";
	var EXT = ew_GetExtObj(sExtName);
	if (EXT && EXT.Enabled) {
		var EXT_TABLE = ew_GetExtTbl(sExtName, TABLE.TblName);
		if (EXT_TABLE) {
			iColumnWidth = ew_GetExtPrp(EXT_TABLE.Properties, "ColumnWidth") || 0;
			iRowHeight = ew_GetExtPrp(EXT_TABLE.Properties, "RowHeight") || 0;
		}
##-->

	// Export to Word
	function ExportReportWord($html) {
		include_once 'PHPWord.php';
		$this->PHPWord($html);
	}

	function PHPWord($html) {
		global $gsExportFile;
		$doc = new DOMDocument();
		$html = preg_replace('/<meta\b(?:[^"\'>]|"[^"]*"|\'[^\']*\')*>/i', "", $html); // Remove meta tags
		@$doc->loadHTML('<?xml encoding="uft-8">' . ew_ConvertToUtf8($html)); // Convert to utf-8
		$tables = $doc->getElementsByTagName("table");
		$phpword = new PHPWord();
		$section = $phpword->createSection();
		$cellwidth = <!--##=iColumnWidth##-->;
		foreach ($tables as $table) {
			if ($table->getAttribute("class") == "ewReportTable") {
				$styleTable = array("borderSize" => 0, "borderColor" => "FFFFFF", "cellMargin" => 10); // Customize table cell styles here
				$phpword->addTableStyle("ewPHPWord", $styleTable);
				$tbl = $section->addTable("ewPHPWord");
				$rows = $table->getElementsByTagName("tr");
				$rowcnt = $rows->length;
				for ($i = 0; $i < $rowcnt; $i++) {
					$row = $rows->item($i);
					if (!($row->parentNode->tagName == "table" && $row->parentNode->getAttribute("class") == "ewTableHeaderBtn")) {
						$cells = $row->childNodes;
						$cellcnt = $cells->length;
						$tbl->addRow(0);
						for ($j = 0; $j < $cellcnt; $j++) {
							$cell = $cells->item($j);
							if ($cell->nodeType <> XML_ELEMENT_NODE || $cell->tagName <> "td")
								continue;
							$k = 1;
							if ($cell->hasAttribute("colspan"))
								$k = intval($cell->getAttribute("colspan"));
							$images = $cell->getElementsByTagName("img");
							if ($images->length == 1 && file_exists($images->item(0)->getAttribute("src"))) { // Image
								$imagefn = $images->item(0)->getAttribute("src");
								$tbl->addCell($cellwidth)->addImage($imagefn);
							} else { // Text
								if ($row->parentNode->tagName == "thead") { // Caption
									$tbl->addCell($cellwidth, array("gridSpan" => $k, "bgColor" => "E4E4E4"))->addText(trim($cell->textContent), array("bold" => TRUE)); // Customize table header cell styles here
								} else {
									$tbl->addCell($cellwidth, array("gridSpan" => $k))->addText(trim($cell->textContent));
								}
							}
						}
					}
				}
			}
		}
		ob_end_clean();
		header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document' . (EW_CHARSET <> '' ? ';charset=' . EW_CHARSET : ''));
		header('Content-Disposition: attachment; filename=' . $gsExportFile . '.docx');
		header('Cache-Control: max-age=0');	
		$objWriter = PHPWord_IOFactory::createWriter($phpword, 'Word2007');
		$objWriter->save('php://output');
		ew_DeleteTmpImages();
		exit();
	}

<!--##
	};
##-->
<!--##/session##-->
?>
