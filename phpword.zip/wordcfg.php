<!--##session wordconfig##-->
<?php
define("EW_USE_PHPWORD", TRUE, TRUE);
?>
<!--##/session##-->