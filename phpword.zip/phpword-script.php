<!--##session exportword##-->
<!--##
	var iColumnWidth = 0;
	var iRowHeight = 0;
	var sExtName = "PHPWord";
	var EXT = ew_GetExtObj(sExtName);
	if (EXT && EXT.Enabled) {
		var EXT_TABLE = ew_GetExtTbl(sExtName, TABLE.TblName);
		if (EXT_TABLE) {
			iColumnWidth = ew_GetExtPrp(EXT_TABLE.Properties, "ColumnWidth") || 0;
			iRowHeight = ew_GetExtPrp(EXT_TABLE.Properties, "RowHeight") || 0;
		}
	}
##-->
<?php
include_once($EW_RELATIVE_PATH . 'PHPWord.php');

$EW_EXPORT['word'] = 'cExportWord2'; // Replace the default cExportWord class

//
// Class for export to Word by PHPWord
// 
class cExportWord2 extends cExportBase {

	var $phpword, $section, $rowheight, $cellwidth, $styleTable, $phpwordTbl;
	var $rowtype;

	// Constructor
	function __construct(&$tbl, $style) {
		parent::__construct($tbl, $style);
		$this->phpword = new PHPWord();
		$this->section = $this->phpword->createSection();
		$this->rowheight = <!--##=iRowHeight##-->;
		$this->cellwidth = <!--##=iColumnWidth##-->;
		$this->styleTable = array("borderSize" => 6, "borderColor" => "A9A9A9", "cellMargin" => 60); // Customize table cell styles here
		$this->phpword->addTableStyle("ewPHPWord", $this->styleTable);
		$this->phpwordTbl = $this->section->addTable("ewPHPWord");
	}

	// Table header
	function ExportTableHeader() {
	}

	// Field aggregate
	function ExportAggregate(&$fld, $type) {
		$this->FldCnt++;
		if ($this->Horizontal) {
			global $Language;
			if ($this->FldCnt == 1)
				$this->phpwordTbl->addRow(0);
			$val = "";
			if (in_array($type, array("TOTAL", "COUNT", "AVERAGE")))
				$val = $Language->Phrase($type) . ": " . ew_ConvertToUtf8($fld->ExportValue());
			$this->phpwordTbl->addCell($this->cellwidth, array("gridSpan" => 1))->addText(trim($val));
		}
	}

	// Field caption
	function ExportCaption(&$fld) {
		$this->FldCnt++;
		$this->ExportCaptionBy($fld, $this->FldCnt - 1, $this->RowCnt);
	}

	// Field caption by column and row
	function ExportCaptionBy(&$fld, $col, $row) {
		if ($col == 0)
			$this->phpwordTbl->addRow(0);
		$val = ew_ConvertToUtf8($fld->ExportCaption());
		$this->phpwordTbl->addCell($this->cellwidth, array("gridSpan" => 1, "bgColor" => "E4E4E4"))->addText(trim($val), array("bold" => TRUE)); // Customize table header cell styles here
	}

	// Field value by column and row
	function ExportValueBy(&$fld, $col, $row) {
		if ($col == 0)
			$this->phpwordTbl->addRow(0);
		$val = "";
		if ($fld->FldViewTag == "IMAGE") { // Image
			$imagefn = $fld->GetTempImage();
			$cell =	$this->phpwordTbl->addCell($this->cellwidth);
			if (!$fld->UploadMultiple || strpos($imagefn,',') === FALSE) {
				$fn = ew_AppRoot() . $imagefn;
				if ($imagefn <> "" && file_exists($fn) && !is_dir($fn)) {
					$cell->addImage($fn);
				}
			} else {
				$ar = explode(",", $imagefn);
				foreach ($ar as $imagefn) {
					$fn = ew_AppRoot() . $imagefn;
					if (!file_exists($fn) || is_dir($fn))
						continue;
					$cell->addImage($fn);
				}
			}
		} elseif (is_array($fld->HrefValue2)) { // Export custom view tag
			$ar = $fld->HrefValue2;
			$fn = is_array($ar) ? @$ar["exportfn"] : ""; // Get export function name
			if (is_callable($fn)) {
				$imagefn = $fn($ar);
				$cell =	$this->phpwordTbl->addCell($this->cellwidth);
				if ($imagefn <> "") {
					$fn = ew_AppRoot() . $imagefn;
					if ($imagefn <> "" && file_exists($fn) && !is_dir($fn)) {
						$cell->addImage($fn);
					}
				}
			} else {
				$val = ew_ConvertToUtf8($fld->ExportValue());
				$this->phpwordTbl->addCell($this->cellwidth, array("gridSpan" => 1))->addText(trim($val));
			}
		} else { // Formatted Text
			$val = ew_ConvertToUtf8($fld->ExportValue());
			if ($this->rowtype > 0) { // Not table header/footer
				if (in_array($fld->FldType, array(4, 5, 6, 14, 131))) // If float or currency
					$val = ew_ConvertToUtf8($fld->CurrentValue); // Use original value instead of formatted value
			}
			$this->phpwordTbl->addCell($this->cellwidth, array("gridSpan" => 1))->addText(trim($val));
		}
	}
	
	// Begin a row
	function BeginExportRow($rowcnt = 0, $usestyle = TRUE) {
		$this->RowCnt++;
		$this->FldCnt = 0;
		$this->rowtype = $rowcnt;
	}

	// End a row
	function EndExportRow() {}

	// Empty row
	function ExportEmptyRow() {
		$this->RowCnt++;
	}
	
	// Page break
	function ExportPageBreak() {}

	// Export a field
	function ExportField(&$fld) {
		$this->FldCnt++;
		if ($this->Horizontal) {
			$this->ExportValueBy($fld, $this->FldCnt - 1, $this->RowCnt);
		} else { // Vertical, export as a row
			$this->RowCnt++;
			$this->ExportCaptionBy($fld, 0, $this->RowCnt);
			$this->ExportValueBy($fld, 1, $this->RowCnt);
		}
	}

	// Table footer
	function ExportTableFooter() {}
	
	// Add HTML tags
	function ExportHeaderAndFooter() {}
	
	// Export
	function Export() {
		global $gsExportFile;
		if (!EW_DEBUG_ENABLED && ob_get_length())
			ob_end_clean();
		header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document' . ((EW_CHARSET <> "") ? ";charset=" . EW_CHARSET : ""));
		header('Content-Disposition: attachment; filename=' . $gsExportFile . '.docx');
		header('Cache-Control: max-age=0');
		$objWriter = PHPWord_IOFactory::createWriter($this->phpword, 'Word2007');
		$objWriter->save('php://output');
		ew_DeleteTmpImages();
	}
	
	// Destructor
	function __destruct() {
		ew_DeleteTmpImages();
	}

}
?>
<!--##/session##-->

