<?php
<!--##session report_excel_function##-->
<!--##
	if (bExportExcel) {
		var sExportExcelFormat = 'Excel5';
		var EXT = ew_GetExtObj("PHPExcel");
		if (EXT.Enabled && EXT.PROJ) {
			var sExportExcelFormatWrk = ew_GetExtPrp(EXT.PROJ.Properties, "Format");
			if (ew_IsNotEmpty(sExportExcelFormatWrk))
				sExportExcelFormat = sExportExcelFormatWrk;
		}
##-->

	// Export report to EXCEL
	function ExportReportExcel($html) {
		include_once 'phpexcel181/Classes/PHPExcel.php';
		$this->PHPExcel($html, "<!--##=sExportExcelFormat##-->");
	}

	function PHPExcel($html, $format = "Excel5") {
		global $gsExportFile;
		$doc = new DOMDocument();
		$html = preg_replace('/<meta\b(?:[^"\'>]|"[^"]*"|\'[^\']*\')*>/i', "", $html); // Remove meta tags
		@$doc->loadHTML('<?xml encoding="uft-8">' . ew_ConvertToUtf8($html)); // Convert to utf-8
		$tables = $doc->getElementsByTagName("table");
		$phpexcel = new PHPExcel();
		$phpexcel->setActiveSheetIndex(0);
		if ($this->ExportExcelPageOrientation <> "")
			$phpexcel->getActiveSheet()->getPageSetup()->setOrientation($this->ExportExcelPageOrientation);
		if ($this->ExportExcelPageSize <> "")
			$phpexcel->getActiveSheet()->getPageSetup()->setPaperSize($this->ExportExcelPageSize);
		if (function_exists("PHPExcel_Rendering")) // For user's own use only
			PHPExcel_Rendering($phpexcel->getActiveSheet());

		$m = 1; $maxcellcnt = 1;
		foreach ($tables as $table) {
			if ($table->getAttribute("class") == "ewReportTable") {
				$rows = $table->getElementsByTagName("tr");
				$rowcnt = $rows->length;
				for ($i = 0; $i < $rowcnt; $i++) {
					$row = $rows->item($i);
					$cells = $row->childNodes;
					$cellcnt = $cells->length;
					$k = 0;
					for ($j = 0; $j < $cellcnt; $j++) {
						$cell = $cells->item($j);
						if ($cell->nodeType <> XML_ELEMENT_NODE || $cell->tagName <> "td")
							continue;
						$images = $cell->getElementsByTagName("img");
						if ($images->length == 1 && file_exists($images->item(0)->getAttribute("src"))) { // Image
							$imagefn = $images->item(0)->getAttribute("src");
							$sheet = $phpexcel->getActiveSheet();
							$objDrawing = new PHPExcel_Worksheet_Drawing();
							$objDrawing->setWorksheet($sheet);
							$objDrawing->setPath(ew_AppRoot() . $imagefn);
							$size = getimagesize(ew_AppRoot() . $imagefn); // Get image size
							$letter = PHPExcel_Cell::stringFromColumnIndex($k);
							if ($size[0] > 0) // Width
								$sheet->getColumnDimension($letter)->setWidth($size[0] * 0.3); // Set column width, adjust the multiplying factor if necessary
							if ($size[1] > 0) // Height
								$sheet->getRowDimension($m)->setRowHeight($size[1]); // Set row height
							$objDrawing->setCoordinates($letter . strval($m));
						} else { // Text
							$value = trim($cell->textContent);
							if (function_exists("PHPExcel_Cell_Rendering")) // For user's own use only
								PHPExcel_Cell_Rendering($k, $m, $value, $phpexcel->getActiveSheet());
							if ($format == "Excel2007" && $row->parentNode->tagName == "thead") { // Caption
								$objRichText = new PHPExcel_RichText(); // Rich Text
								$obj = $objRichText->createTextRun($value);
								$obj->getFont()->setBold(TRUE); // Bold
								//$obj->getFont()->setItalic(true);
								//$obj->getFont()->setColor(new PHPExcel_Style_Color(PHPExcel_Style_Color::COLOR_DARKGREEN)); // Set color
								$phpexcel->getActiveSheet()->getCellByColumnAndRow($k, $m)->setValue($objRichText);
							} else {
								$phpexcel->getActiveSheet()->setCellValueByColumnAndRow($k, $m, $value);
							}
							if (function_exists("PHPExcel_Cell_Rendered")) // For user's own use only
								PHPExcel_Cell_Rendered($k, $m, $value, $phpexcel->getActiveSheet());
						}
						if ($cell->hasAttribute("colspan")) {
							$k += intval($cell->getAttribute("colspan"));
						} else {
							$k++;
						}
					}
					if ($k > $maxcellcnt) $maxcellcnt = $k;
					$m++;
				}
				$m++;
			}
		}
		ob_end_clean();
		if ($format == "Excel5") {
			header('Content-Type: application/vnd.ms-excel;charset=utf-8');
			header('Content-Disposition: attachment; filename=' . $gsExportFile . '.xls');
		} else { // Excel2007
			header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8');
			header('Content-Disposition: attachment; filename=' . $gsExportFile . '.xlsx');
		}
		header('Cache-Control: max-age=0');	
		$objWriter = PHPExcel_IOFactory::createWriter($phpexcel, $format);
		$objWriter->save('php://output');
		ew_DeleteTmpImages();
		exit();
	}

<!--##
	};
##-->
<!--##/session##-->
?>
