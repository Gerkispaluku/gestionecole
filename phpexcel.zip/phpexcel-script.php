<!--##session excelconfig##-->
<!--##
	var sExportExcelFormat;
	var sExcelPageOrientation = "\"\"";
	var sExcelPageSize = "\"\"";
	var sExtName = "PHPExcel";
	var EXT = ew_GetExtObj(sExtName);
	if (EXT.Enabled && EXT.PROJ) {
		sExportExcelFormat = ew_GetExtPrp(EXT.PROJ.Properties, "Format");
		var EXT_TABLE = ew_GetExtTbl(sExtName, TABLE.TblName);
		if (EXT_TABLE) {
			sExcelPageOrientation = ew_GetExtPrp(EXT_TABLE.Properties, "PageOrientation");
			if (sExcelPageOrientation != "")
				sExcelPageOrientation = "PHPExcel_Worksheet_PageSetup::" + sExcelPageOrientation;
			sExcelPageSize = ew_GetExtPrp(EXT_TABLE.Properties, "PageSize");
			if (sExcelPageSize != "")
				sExcelPageSize = "PHPExcel_Worksheet_PageSetup::" + sExcelPageSize;
		}
	}

	if (!sExportExcelFormat)
		sExportExcelFormat = 'Excel5';
##-->
<!--##/session##-->

<!--##session exportexcel##-->
<?php
include_once($EW_RELATIVE_PATH . 'phpexcel181/Classes/PHPExcel.php');

<!--## if (sExportExcelFormat == 'Excel5') { ##-->
$EW_EXPORT['excel'] = 'cExportExcel5'; // Replace the default cExportExcel class
<!--## } ##-->
<!--## if (sExportExcelFormat == 'Excel2007') { ##-->
$EW_EXPORT['excel'] = 'cExportExcel2007'; // Replace the default cExportExcel class
<!--## } ##-->
$EW_EXPORT['excel2007'] = 'cExportExcel2007';

//
// Class for export to Excel5 by PHPExcel
// 
class cExportExcel5 extends cExportBase {

	var $phpexcel;
	var $rowtype;
	var $PageOrientation = PHPExcel_Worksheet_PageSetup::ORIENTATION_DEFAULT;
	var $PageSize = PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4;

	// Constructor
	function __construct(&$tbl, $style) {
		parent::__construct($tbl, $style);
		$this->phpexcel = new PHPExcel();
		$this->phpexcel->setActiveSheetIndex(0);
		if ($tbl->ExportExcelPageOrientation <> "") $this->PageOrientation = $tbl->ExportExcelPageOrientation;
		if ($tbl->ExportExcelPageSize <> "") $this->PageSize = $tbl->ExportExcelPageSize;
		$this->phpexcel->getActiveSheet()->getPageSetup()->setOrientation($this->PageOrientation);
		$this->phpexcel->getActiveSheet()->getPageSetup()->setPaperSize($this->PageSize);
		if (function_exists("PHPExcel_Rendering")) // For user's own use only
			PHPExcel_Rendering($this->phpexcel->getActiveSheet());
	}

	// Set value by column and row
	function SetCellValueByColumnAndRow($col, $row, $val) {
		$val = trim($val);
		if (function_exists("PHPExcel_Cell_Rendering")) // For user's own use only
			PHPExcel_Cell_Rendering($col, $row, $val, $this->phpexcel->getActiveSheet());
		$this->phpexcel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, $val);
		if (function_exists("PHPExcel_Cell_Rendered")) // For user's own use only
			PHPExcel_Cell_Rendered($col, $row, $val, $this->phpexcel->getActiveSheet());
	}

	// Table header
	function ExportTableHeader() {}

	// Field aggregate
	function ExportAggregate(&$fld, $type) {
		$this->FldCnt++;
		if ($this->Horizontal) {
			global $Language;
			$val = "";
			if (in_array($type, array("TOTAL", "COUNT", "AVERAGE")))
				$val = $Language->Phrase($type) . ": " . ew_ConvertToUtf8($fld->ExportValue());
			$this->SetCellValueByColumnAndRow($this->FldCnt - 1, $this->RowCnt, $val);
		}
	}

	// Field caption
	function ExportCaption(&$fld) {
		$this->FldCnt++;
		$this->ExportCaptionBy($fld, $this->FldCnt - 1, $this->RowCnt);
	}
	
	// Field caption by column and row
	function ExportCaptionBy(&$fld, $col, $row) {
		$val = ew_ConvertToUtf8($fld->ExportCaption());
		$this->SetCellValueByColumnAndRow($col, $row, $val); // Plain text
	}
	
	// Field value by column and row
	function ExportValueBy(&$fld, $col, $row) {
		$val = "";
		if ($fld->FldViewTag == "IMAGE") { // Image
			$imagefn = $fld->GetTempImage();
			if (!$fld->UploadMultiple || strpos($imagefn,',') === FALSE) {
				$fn = ew_AppRoot() . $imagefn;
				if ($imagefn <> "" && file_exists($fn) && !is_dir($fn)) {
					$sheet = $this->phpexcel->getActiveSheet();
					$objDrawing = new PHPExcel_Worksheet_Drawing();
					$objDrawing->setWorksheet($sheet);
					$objDrawing->setPath($fn);
					$size = getimagesize($fn); // Get image size
					$letter = PHPExcel_Cell::stringFromColumnIndex($col);
					if ($size[0] > 0) // Width
						$sheet->getColumnDimension($letter)->setWidth($size[0] * 0.3); // Set column width, adjust the multiplying factor if necessary
					if ($size[1] > 0) // Height
						$sheet->getRowDimension($row)->setRowHeight($size[1]); // Set row height
					$objDrawing->setCoordinates($letter . strval($row));
				}
			} else {
				$ar = explode(",", $imagefn);
				$totalW = 0;
				$maxH = 0;
				foreach ($ar as $imagefn) {
					$fn = ew_AppRoot() . $imagefn;
					if (!file_exists($fn) || is_dir($fn))
						continue;
					$sheet = $this->phpexcel->getActiveSheet();
					$objDrawing = new PHPExcel_Worksheet_Drawing();
					$objDrawing->setWorksheet($sheet);
					$objDrawing->setPath($fn);
					$size = getimagesize($fn); // Get image size
					$letter = PHPExcel_Cell::stringFromColumnIndex($col);
					$objDrawing->setOffsetX($totalW);
					$objDrawing->setCoordinates($letter . strval($row));
					if ($size[0] > 0) // Width
						$totalW += $size[0];
					if ($size[1] > 0 && $size[1] > $maxH) // Height
						$maxH = $size[1];
				}
				if ($totalW > 0) // Width
					$sheet->getColumnDimension($letter)->setWidth($totalW * 0.3); // Set column width, adjust the multiplying factor if necessary
				if ($maxH > 0) // Height
					$sheet->getRowDimension($row)->setRowHeight($maxH); // Set row height
			}
		} elseif (is_array($fld->HrefValue2)) { // Export custom view tag
			$ar = $fld->HrefValue2;
			$fn = is_array($ar) ? @$ar["exportfn"] : ""; // Get export function name
			if (is_callable($fn)) {
				$imagefn = $fn($ar);
				if ($imagefn <> "") {
					$fn = ew_AppRoot() . $imagefn;
					if ($imagefn <> "" && file_exists($fn) && !is_dir($fn)) {
						$sheet = $this->phpexcel->getActiveSheet();
						$objDrawing = new PHPExcel_Worksheet_Drawing();
						$objDrawing->setWorksheet($sheet);
						$objDrawing->setPath($fn);
						$size = getimagesize($fn); // Get image size
						$letter = PHPExcel_Cell::stringFromColumnIndex($col);
						if ($size[0] > 0) // Width
							$sheet->getColumnDimension($letter)->setWidth($size[0] * 0.3); // Set column width, adjust the multiplying factor if necessary
						if ($size[1] > 0) // Height
							$sheet->getRowDimension($row)->setRowHeight($size[1]); // Set row height
						$objDrawing->setCoordinates($letter . strval($row));
					}
				}
			} else {
				$val = ew_ConvertToUtf8($fld->ExportValue());
				$this->SetCellValueByColumnAndRow($col, $row, $val);
			}
		} else { // Formatted Text
			$val = ew_ConvertToUtf8($fld->ExportValue());
			if ($this->rowtype > 0) { // Not table header/footer
				if (in_array($fld->FldType, array(4, 5, 6, 14, 131))) // If float or currency
					$val = ew_ConvertToUtf8($fld->CurrentValue); // Use original value instead of formatted value
			}
			$this->SetCellValueByColumnAndRow($col, $row, $val);
		}
	}
	
	// Begin a row
	function BeginExportRow($rowcnt = 0, $usestyle = TRUE) {
		$this->RowCnt++;
		$this->FldCnt = 0;
		$this->rowtype = $rowcnt;
	}

	// End a row
	function EndExportRow() {}

	// Empty row
	function ExportEmptyRow() {
		$this->RowCnt++;
	}
	
	// Page break
	function ExportPageBreak() {}

	// Export a field
	function ExportField(&$fld) {
		$this->FldCnt++;
		if ($this->Horizontal) {
			$this->ExportValueBy($fld, $this->FldCnt - 1, $this->RowCnt);
		} else { // Vertical, export as a row
			$this->RowCnt++;
			$this->ExportCaptionBy($fld, 0, $this->RowCnt);
			$this->ExportValueBy($fld, 1, $this->RowCnt);
		}
	}

	// Table footer
	function ExportTableFooter() {}
	
	// Add HTML tags
	function ExportHeaderAndFooter() {}
	
	// Export
	function Export() {
		global $gsExportFile;
		if (!EW_DEBUG_ENABLED && ob_get_length())
			ob_end_clean();
		header('Content-Type: application/vnd.ms-excel' . ((EW_CHARSET <> "") ? ";charset=" . EW_CHARSET : ""));
		header('Content-Disposition: attachment; filename=' . $gsExportFile . '.xls');
		header('Cache-Control: max-age=0');
		$objWriter = PHPExcel_IOFactory::createWriter($this->phpexcel, 'Excel5');
		$objWriter->save('php://output');
		ew_DeleteTmpImages();
	}
	
	// Destructor
	function __destruct() {
		ew_DeleteTmpImages();
	}

}

//
// Class for export to Excel2007 by PHPExcel
// 
class cExportExcel2007 extends cExportExcel5 {

	// Field caption by column and row
	function ExportCaptionBy(&$fld, $col, $row) {
		$val = ew_ConvertToUtf8($fld->ExportCaption());
		// Example: Use rich text for caption
		$objRichText = new PHPExcel_RichText(); // Rich Text
		$obj = $objRichText->createTextRun($val);
		$obj->getFont()->setBold(TRUE); // Bold
		//$obj->getFont()->setItalic(true);
		//$obj->getFont()->setColor(new PHPExcel_Style_Color(PHPExcel_Style_Color::COLOR_DARKGREEN)); // Set color
		$this->phpexcel->getActiveSheet()->getCellByColumnAndRow($col, $row)->setValue($objRichText);
	}
	
	// Export
	function Export() {
		global $gsExportFile;
		ob_end_clean();
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' . ((EW_CHARSET <> "") ? ";charset=" . EW_CHARSET : ""));
		header('Content-Disposition: attachment; filename=' . $gsExportFile . '.xlsx');
		header('Cache-Control: max-age=0');
		$objWriter = PHPExcel_IOFactory::createWriter($this->phpexcel, 'Excel2007');
		$objWriter->save('php://output');
		ew_DeleteTmpImages();
	}
}
?>
<!--##/session##-->

