<!--##session config_scrolltable##-->
<!--##
	var bUseScrollTable = false;
	var sScrollWidth = "";
	var sScrollHeight = "";
	var sExtName = "ScrollingTable";
	var EXT = ew_GetExtObj(sExtName);
	if (EXT && EXT.Enabled) {
		var EXT_TABLE = ew_GetExtTbl(sExtName, TABLE.TblName);
		if (EXT_TABLE) {
			if (ew_GetExtPrp(EXT_TABLE.Properties, "Scrollable")) {
				bUseScrollTable = true;
				sScrollWidth = ew_GetExtPrp(EXT_TABLE.Properties, "ScrollWidth");
				if (parseInt(sScrollWidth) <= 0) {
					sScrollWidth = "";
				} else {
					sScrollWidth += "px";
				}
				sScrollHeight = ew_GetExtPrp(EXT_TABLE.Properties, "ScrollHeight");
				if (parseInt(sScrollHeight) <= 0) {
					sScrollHeight = "";
				} else {
					sScrollHeight += "px";
				}
			}
		}
	}

	var bGenScrollTable = (CTRL.CtrlID == "list" && bUseScrollTable);

	sTblVar = gsTblVar;
##-->
<!--##/session##-->
