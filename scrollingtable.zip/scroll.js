<!--##session js_scrolltable##-->
<!--##
	if (bGenScrollTable) {
##-->
<script type="text/javascript" src="<!--##=ew_GetFileNameByCtrlID("ewscrolltable.js")##-->"></script>
<!--##
	}
##-->
<!--##/session##-->

<!--##session js_scrolltable_css##-->


<!--##/session##-->

<!--##session js_scrolltable_init##-->
<!--##
	if (bGenScrollTable) {
##-->
<?php if ($<!--##=gsTblVar##-->->CurrentAction == "" && $<!--##=gsTblVar##-->->Export == "") { ?>
<script type="text/javascript">
ew_ScrollableTable("gmp_<!--##=gsTblVar##-->", "<!--##=sScrollWidth##-->", "<!--##=sScrollHeight##-->");
</script>
<?php } ?>
<!--##
	}
##-->
<!--##/session##-->
