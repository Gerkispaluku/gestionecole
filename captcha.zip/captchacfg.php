<!--##session captchaconfig##-->
<!--##
	var sCaptchaFont = "aftershock"; // default
	var sExtName = "CAPTCHA";
	var EXT = ew_GetExtObj(sExtName);
	if (EXT.Enabled && EXT.PROJ) {
		var sCaptchaFontWrk = ew_GetExtPrp(EXT.PROJ.Properties, "Font");
		if (ew_IsNotEmpty(sCaptchaFontWrk))
			sCaptchaFont = sCaptchaFontWrk;
		if (sCaptchaFont.lastIndexOf('.') > 0) // Remove extension
			sCaptchaFont = sCaptchaFont.substr(0, sCaptchaFont.lastIndexOf('.'));
	}
##-->
<?php
define("EW_CAPTCHA_FONT", "<!--##=sCaptchaFont##-->", TRUE);
?>
<!--##/session##-->