<!--##session phpcaptcha_config##-->
<!--##
	// Check if Use Captcha
	var bUseCaptcha = false;
	var bConfirmCaptcha = false;
	var sCaptchaDivControlClass = " class=\"col-sm-offset-2 col-sm-10\"";
	var EXT = ew_GetExtObj("CAPTCHA");
	var bUseReCaptcha = false;
	var sReCaptchaPublicKey = "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"; // CHANGE THIS TO YOUR OWN KEY!
	var sReCaptchaPrivateKey = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe"; // CHANGE THIS TO YOUR OWN KEY!
	var sReCaptchaTheme = "light";
	var sReCaptchaType = "image";
	var sReCaptchaSize = "normal";
	var bUseCaptchaInLoginPage = false;
	if (EXT && EXT.PROJ && EXT.PROJ.Properties && EXT.PROJ.Properties.length) {
		for (var i = 0, len = EXT.PROJ.Properties.length; i < len; i++) {
			var prp = EXT.PROJ.Properties[i];
			if (prp.Id == "ReCaptchaPublicKey" && ew_IsNotEmpty(prp.Value))
				sReCaptchaPublicKey = prp.Value;
			else if (prp.Id == "ReCaptchaPrivateKey" && ew_IsNotEmpty(prp.Value))
				sReCaptchaPrivateKey = prp.Value;
			else if (prp.Id == "ReCaptchaTheme" && ew_IsNotEmpty(prp.Value))
				sReCaptchaTheme = prp.Value;
			else if (prp.Id == "ReCaptchaType" && ew_IsNotEmpty(prp.Value))
				sReCaptchaType = prp.Value;
			else if (prp.Id == "ReCaptchaSize" && ew_IsNotEmpty(prp.Value))
				sReCaptchaSize = prp.Value;
			else if (prp.Id == "UseReCaptcha" && ew_IsNotEmpty(prp.Value))
				bUseReCaptcha = prp.Value == "1";
			else if (prp.Id == "UseCaptchaInLoginPage" && ew_IsNotEmpty(prp.Value))
				bUseCaptchaInLoginPage = prp.Value == "1";
		}
	}

	if (EXT && EXT.Enabled) {
		if (CTRL.CtrlID == "register") {
			if (PROJ.SecRegisterCaptcha) {
				bUseCaptcha = true;
				bConfirmCaptcha = PROJ.SecRegisterConfirm;
			}
		} else if (CTRL.CtrlID == "login") {
			if (PROJ.SecLoginCaptcha || bUseCaptchaInLoginPage) {
				bUseCaptcha = true;
				bConfirmCaptcha = false;
			}
		} else if (CTRL.CtrlID == "forgotpwd") {
			if (PROJ.SecForgotPwdCaptcha) {
				bUseCaptcha = true;
				bConfirmCaptcha = false;
			}
		} else if (CTRL.CtrlID == "changepwd") {
			if (PROJ.SecChangePwdCaptcha) {
				bUseCaptcha = true;
				bConfirmCaptcha = false;
			}
		} else if (CTRL.CtrlID == "add") {
			if (TABLE.TblAddCaptcha) {
				bUseCaptcha = true;
				bConfirmCaptcha = TABLE.TblAddConfirm;
			}
		} else if (CTRL.CtrlID == "edit") {
			if (TABLE.TblEditCaptcha) {
				bUseCaptcha = true;
				bConfirmCaptcha = TABLE.TblEditConfirm;
			}
		} else if (CTRL.CtrlID == "header") {
			bUseCaptcha = true;
		}
	}

	bUseReCaptcha = bUseReCaptcha && bUseCaptcha && sReCaptchaPublicKey != "" && sReCaptchaPrivateKey != "";

	// Get table variable
	sTblVar = gsTblVar;

	var sCaptchaResponseField = (bUseReCaptcha) ? "g-recaptcha-response" : "captcha";
##-->
<!--##/session##-->

<!--##session phpcaptcha_var##-->
<!--##
	if (bUseCaptcha) {
##-->
	// CAPTCHA
	var $captcha;

	<!--##
		if (bUseReCaptcha) {	
	##-->
	var $ReCaptchaPublicKey = "<!--##=sReCaptchaPublicKey##-->";
	var $ReCaptchaPrivateKey = "<!--##=sReCaptchaPrivateKey##-->";
	var $ReCaptchaLanguage = "en";
	var $ReCaptchaTheme = "<!--##=sReCaptchaTheme##-->";
	var $ReCaptchaType = "<!--##=sReCaptchaType##-->";
	var $ReCaptchaSize = "<!--##=sReCaptchaSize##-->";

	// Validate Captcha
	function ValidateCaptcha() {
		include_once("ReCaptcha/ReCaptcha.php");
		include_once("ReCaptcha/RequestMethod.php");
		include_once("ReCaptcha/RequestParameters.php");
		include_once("ReCaptcha/Response.php");
		include_once("ReCaptcha/RequestMethod/Curl.php");
		include_once("ReCaptcha/RequestMethod/CurlPost.php");
		include_once("ReCaptcha/RequestMethod/Post.php");
		include_once("ReCaptcha/RequestMethod/Socket.php");
		include_once("ReCaptcha/RequestMethod/SocketPost.php");
		if ($this->captcha == @$_SESSION["EW_CAPTCHA_CODE"]) {
			return TRUE;
		} else {
			$recaptcha = new \ReCaptcha\ReCaptcha($this->ReCaptchaPrivateKey);
			$resp = $recaptcha->verify($this->captcha, @$_SERVER["REMOTE_ADDR"]);
			if ($resp != null && $resp->isSuccess()) {
				$_SESSION["EW_CAPTCHA_CODE"] = $this->captcha;
				return TRUE;
			} else {
				return FALSE;
			}
		}
	}
		
	// Reset Captcha
	function ResetCaptcha() {
		$_SESSION["EW_CAPTCHA_CODE"] = ew_Random();
		$this->ReCaptchaLanguage = $GLOBALS["gsLanguage"];
	}
	<!--##
		} else if (bUseCaptcha) {	
	##-->
	// Validate Captcha
	function ValidateCaptcha() {
		return ($this->captcha == @$_SESSION["EW_CAPTCHA_CODE"]);
	}
		
	// Reset Captcha
	function ResetCaptcha() {
		$_SESSION["EW_CAPTCHA_CODE"] = ew_Random();
	}
	<!--##
		}
	##-->

<!--##
	}
##-->
<!--##/session##-->

<!--##session phpcaptcha_php##-->
<!--##
	if (bUseCaptcha) {
		if (CTRL.CtrlID == "add" || CTRL.CtrlID == "register") {
##-->
		// CAPTCHA checking
		if ($this->CurrentAction == "I" || $this->CurrentAction == "C") {
			$this->ResetCaptcha();
		} elseif (ew_IsHttpPost()) {
			$objForm->Index = -1;
			$this->captcha = $objForm->GetValue("<!--##=sCaptchaResponseField##-->");
			if (!$this->ValidateCaptcha()) { // CAPTCHA unmatched
				$this->setFailureMessage($Language->Phrase("EnterValidateCode"));
				$this->CurrentAction = "I"; // Reset action, do not insert
				$this->EventCancelled = TRUE; // Event cancelled
				$this->RestoreFormValues(); // Restore form values
			} else {
				if ($this->CurrentAction == "A")
					$this->ResetCaptcha();
			}
		}
<!--##
		} else if (CTRL.CtrlID == "edit") {
##-->
		// CAPTCHA checking
		if ($this->CurrentAction == "I") {
			$this->ResetCaptcha();
		} elseif (ew_IsHttpPost()) {
			$objForm->Index = -1;
			$this->captcha = $objForm->GetValue("<!--##=sCaptchaResponseField##-->");
			if (!$this->ValidateCaptcha()) { // CAPTCHA unmatched
				$this->setFailureMessage($Language->Phrase("EnterValidateCode")); // Set message
				$this->CurrentAction = ""; // Reset action, do not update
				$this->EventCancelled = TRUE; // Event cancelled
				$this->RestoreFormValues(); // Restore form values
			} else {
				if ($this->CurrentAction == "U")
					$this->ResetCaptcha();
			}
		}
<!--##
		} else if (CTRL.CtrlID == "login") {
##-->
		// CAPTCHA checking
		if (ew_IsHttpPost()) {
			$this->captcha = @$_POST["<!--##=sCaptchaResponseField##-->"];
			if (!$this->ValidateCaptcha()) { // CAPTCHA unmatched
				$this->setFailureMessage($Language->Phrase("EnterValidateCode")); // Set message
				$bValidate = FALSE;
			}
		}
		if (!$bValidate) {
			$this->ResetCaptcha();
		}
<!--##
		} else if (CTRL.CtrlID == "forgotpwd") {
##-->
		// CAPTCHA checking
		if (ew_IsHttpPost()) {
			$this->captcha = @$_POST["<!--##=sCaptchaResponseField##-->"];
			if (!$this->ValidateCaptcha()) { // CAPTCHA unmatched
				$this->setFailureMessage($Language->Phrase("EnterValidateCode")); // Set message
				$bValidEmail = FALSE;
				$this->Action = "";
			}
		}
		if (!$bValidEmail) {
			$this->ResetCaptcha();
		}
<!--##
		} else if (CTRL.CtrlID == "changepwd") {
##-->
		// CAPTCHA checking
		if (ew_IsHttpPost()) {
			$this->captcha = @$_POST["<!--##=sCaptchaResponseField##-->"];
			if (!$this->ValidateCaptcha()) { // CAPTCHA unmatched
				$this->setFailureMessage($Language->Phrase("EnterValidateCode")); // Set message
				$bValidate = FALSE;
			}
		}
		if (!$bValidate) {
			$this->ResetCaptcha();
		}
<!--##
		}
	}
##-->
<!--##/session##-->


<!--##session recaptcha_js_client##-->
<!--## 
if (bUseReCaptcha) { ##-->
<script type="text/javascript" src="https://www.google.com/recaptcha/api.js?onload=ew_InitReCaptcha&render=explicit&hl=<?php echo CurrentLanguageID(); ?>"></script>
<script type="text/javascript">
function ew_InitReCaptcha() {
	var $ = jQuery;
	$(function() {
		$(".g-recaptcha").each(function() {
			grecaptcha.render(this, {
				"sitekey": "<!--##=sReCaptchaPublicKey##-->",
				"theme": "<!--##=sReCaptchaTheme##-->",
				"type": "<!--##=sReCaptchaType##-->",
				"size": "<!--##=sReCaptchaSize##-->"
			});
		})
	});
}

jQuery(function() {
	$("#ewModalDialog").on("load.ew", ew_InitReCaptcha);
});
</script>
<!--## } ##-->
<!--##/session##-->


<!--##session phpcaptcha_htm##-->
<!--##
	if (ew_InArray(CTRL.CtrlID, ["login", "forgotpwd", "changepwd"]) > -1)
		bCatpchaUseTabularFormForDesktop = false;
	else
		bCatpchaUseTabularFormForDesktop = bUseTabularFormForDesktop;
	if (bUseReCaptcha) {
		if (ew_InArray(CTRL.CtrlID, ["add", "register", "edit", "login", "forgotpwd", "changepwd"]) > -1) {
##-->
<!--## if (bConfirmCaptcha) { ##-->
<?php if ($<!--##=gsTblVar##-->->CurrentAction <> "F") { ?>
<!--## } ##-->

<!-- captcha html (begin) -->

<!--## if (bCatpchaUseTabularFormForDesktop) { ##-->
<?php if (ew_IsMobile()) { ?>
<!--## } ##-->

<div class="form-group">
	<div<!--##=sCaptchaDivControlClass##-->>

<!--## if (bCatpchaUseTabularFormForDesktop) { ##-->
<?php } else { ?>
<div class="ewDesktopButton">
<?php } ?>
<!--## } ##-->

	<div class="g-recaptcha"></div>

<!--## if (bCatpchaUseTabularFormForDesktop) { ##-->
<?php if (ew_IsMobile()) { ?>
<!--## } ##-->

	</div>
</div>

<!--## if (bCatpchaUseTabularFormForDesktop) { ##-->
<?php } else { ?>
</div>
<?php } ?>
<!--## } ##-->

<!--## if (bConfirmCaptcha) { ##-->
<?php } else { ?>
<input type="hidden" name="g-recaptcha-response" id="g-recaptcha-response" value="<?php echo $<!--##=sPageObj##-->->captcha ?>">
<?php } ?>
<!--## } ##-->

<!-- captcha html (end) -->

<!--##
		}
	} else if (bUseCaptcha) {
##-->

<!--## if (bConfirmCaptcha) { ##-->
<?php if ($<!--##=gsTblVar##-->->CurrentAction <> "F") { ?>
<!--## } ##-->

<!-- captcha html (begin) -->

<!--## if (bCatpchaUseTabularFormForDesktop) { ##-->
<?php if (ew_IsMobile()) { ?>
<!--## } ##-->

<div class="form-group">
	<div<!--##=sCaptchaDivControlClass##-->>

<!--## if (bCatpchaUseTabularFormForDesktop) { ##-->
<?php } else { ?>
<div class="ewDesktopButton">
<?php } ?>
<!--## } ##-->

	<img src="<!--##=ew_GetFileNameByCtrlID("ewcaptcha.php")##-->" alt="Security Image" style="width: 200px; height: 50px;"><br><br>
	<input type="text" name="captcha" id="captcha" class="form-control" size="30" placeholder="<!--##@EnterValidateCode##-->">

<!--## if (bCatpchaUseTabularFormForDesktop) { ##-->
<?php if (ew_IsMobile()) { ?>
<!--## } ##-->

	</div>
</div>

<!--## if (bCatpchaUseTabularFormForDesktop) { ##-->
<?php } else { ?>
</div>
<?php } ?>
<!--## } ##-->

<!--## if (bConfirmCaptcha) { ##-->
<?php } else { ?>
<input type="hidden" name="captcha" id="captcha" value="<?php echo $<!--##=sPageObj##-->->captcha ?>">
<?php } ?>
<!--## } ##-->

<!-- captcha html (end) -->

<!--##
	}
##-->
<!--##/session##-->


<!--##session phpcaptcha_js##-->
	<!--##
		if (bUseReCaptcha) {
	##-->
		if (grecaptcha && grecaptcha.getResponse() == "") {
			ew_Alert(ewLanguage.Phrase("ClickReCaptcha"));
			return false;
		}
	<!--##
		} else if (bUseCaptcha) {
	##-->
		if (fobj.captcha && !ew_HasValue(fobj.captcha))
			return this.OnError(fobj.captcha, ewLanguage.Phrase("EnterValidateCode"));
	<!--##
		}
	##-->
<!--##/session##-->