<!--##session ewconfigpreview##-->
<?php
define("EW_ROWTYPE_PREVIEW", 11, TRUE); // Preview record
?>
<!--##/session##-->