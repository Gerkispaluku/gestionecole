<!--##session setupoption##-->
<!--## if (bPreviewRow) { ##-->

		// Hide detail items for dropdown if necessary
		$this->ListOptions->HideDetailItemsForDropDown();

<!--## } ##-->
<!--##/session##-->

<!--##session renderoption##-->
<!--##
	var sImageFolder = ew_GetImageFolder();

	// Make sure that there is at least one non-report detail table
	var bGenDetailColumn = false;
	for (var i = 0, len = arDetailTables.length; i < len; i++) {
		var MasterDetail = goAllMasDets[arDetailTables[i].index];
		DETAILTABLE = ew_GetTblObj(MasterDetail.DetailTable);
		if (DETAILTABLE.TblGen && DETAILTABLE.TblType != "REPORT") {
			bGenDetailColumn = true;
			break;
		}
	}
	if (bUseDetailPreview && nDetailTableCount > 0 && bGenDetailColumn) {
		if (TABLE.TblUseGlobal) {
			bLinkOnLeft = PROJ.LinkOnLeft;
		} else {
			bLinkOnLeft = TABLE.TblLinkOnLeft;
		}
##-->
		$links = "";
		$btngrps = "";
<!--##
		var k = -1;
		for (var i = 0, len = arDetailTables.length; i < len; i++) {
			var MasterDetail = goAllMasDets[arDetailTables[i].index];			
			MASTERTABLE = TABLE; // Save master table
			TABLE = ew_GetTblObj(MasterDetail.DetailTable);
			sDetailPageObj = ew_GetPageObjByCtrlId("grid");
			var sDetailUrl;
			if (TABLE.TblType == "REPORT") {
				sDetailUrl = ew_GetFileNameByCtrlID("report"); // detail list url
			} else {
				sDetailUrl = ew_GetFileNameByCtrlID("list"); // detail list url
			}
			sDetailUrl += "?\" . EW_TABLE_SHOW_MASTER . \"=" + gsTblVar;
			if (TABLE.TblGen && TABLE.TblType != "REPORT") {
				k++;
				var sDetailTblVar = TABLE.TblVar;
				var sFnPreview = ew_GetFileNameByCtrlID("preview");
				var sQry = "";
				var sDbId = ew_GetDbId(TABLE.TblName); // Get detail dbid
				for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
					FIELD = ew_GetFldObj(TABLE, MasterDetail.Rels[j].DetailField);
					sFldExpression = ew_FieldSqlName(FIELD, sDbId);
					sFldQuoteS = FIELD.FldQuoteS;
					sFldQuoteE = FIELD.FldQuoteE;
					FIELD = ew_GetFldObj(MASTERTABLE, MasterDetail.Rels[j].MasterField);
					sFldParm = FIELD.FldParm;
					sQry += "&fk_" + sFldParm + "=";
					var cv = "$this->" + sFldParm + "->CurrentValue";
					if (ew_GetFieldType(FIELD.FldType) == 2) {
						cv = "ew_UnFormatDateTime(" + cv + ", 0)";
						sQry += "\" . urlencode(ew_UnFormatDateTime(" + cv + ", 0)) . \"";
					} else {
						sQry += "\" . urlencode(strval(" + cv + ")) . \"";
					}
					var sPrefix;
					if (j == 0) {
						sPrefix = "";
					} else {
						sPrefix = "$sSqlWrk . \" AND \" . ";
					}
##-->
		$sSqlWrk = <!--##=sPrefix##-->"<!--##=ew_Quote(sFldExpression)##-->=<!--##=sFldQuoteS##-->" . ew_AdjustSql(<!--##=cv##-->, $this->DBID) . "<!--##=sFldQuoteS##-->";
<!--##
				} // MasterDetailField
				sDetailUrl += sQry;
				
				// Set up detail list link visibility
				sDetailListVisible = ew_SecurityCheck("Detail", bSecurityEnabled, bUserTable);
				if (sDetailListVisible == "") sDetailListVisible = "TRUE";
				
				// Set up detail view link visibility
				sDetailViewVisible = ew_SecurityCheck("DetailView", bSecurityEnabled, bUserTable);
				sDetailViewVisible = ew_BuildCond(sMasterViewVisible, "&&", sDetailViewVisible);
				if (sDetailViewVisible != "") sDetailViewVisible = " && " + sDetailViewVisible;

				// Set up detail edit link visibility
				sDetailEditVisible = ew_SecurityCheck("DetailEdit", bSecurityEnabled, bUserTable);
				sDetailEditVisible = ew_BuildCond(sMasterEditVisible, "&&", sDetailEditVisible);
				if (sDetailEditVisible != "") sDetailEditVisible = " && " + sDetailEditVisible;

				// Set up copy link visibility
				sDetailCopyVisible = ew_SecurityCheck("DetailAdd", bSecurityEnabled, bUserTable);
				sDetailCopyVisible = ew_BuildCond(sMasterCopyVisible, "&&", sDetailCopyVisible);
				if (sDetailCopyVisible != "") sDetailCopyVisible = " && " + sDetailCopyVisible;
				bDetailCopy = (bDetailAdd && (MASTERTABLE.TblAdd && MASTERTABLE.TblCopy) && (TABLE.TblAdd && TABLE.TblCopy));
				
				// Use buttons for links
				bUseButtonsForLinks = TABLE.TblUseGlobal && PROJ.UseButtonsForLinks || !TABLE.TblUseGlobal && TABLE.TblUseButtonsForLinks;
				var sBtnGrpCls, sBtnTag, sBtnAttrs;
				if (bUseButtonsForLinks) {
					sBtnGrpCls = " class=\\\"btn-group\\\"";
					sBtnTag = "button";
					sBtnAttrs = " type=\\\"button\\\" class=\\\"btn btn-default btn-sm\\\"";
				} else {
					sBtnGrpCls = "";
					sBtnTag = "a";
					sBtnAttrs = " href=\\\"javascript:void(0);\\\" class=\\\"ewLinkSeparator\\\"";
				}
##-->
		// Column "detail_<!--##=sDetailTblVar##-->"
		if ($this->DetailPages->Items["<!--##=ew_Quote(sDetailTblVar)##-->"]->Visible) {
			$link = "";
			$option = &$this->ListOptions->Items["detail_<!--##=sDetailTblVar##-->"];
			$url = "<!--##=sFnPreview##-->?t=<!--##=gsTblVar##-->&f=" . ew_Encrypt($sSqlWrk);
			$btngrp = "<div data-table=\"<!--##=sDetailTblVar##-->\" data-url=\"" . $url . "\"<!--##=sBtnGrpCls##-->>";
			if (<!--##=sDetailListVisible##-->) {			
				$label = $Language->TablePhrase("<!--##=sDetailTblVar##-->", "TblCaption");
		<!--## if (bDetailShowCount) { ##-->
				$label .= "&nbsp;" . ew_JsEncode2(str_replace("%c", $this-><!--##=sDetailTblVar##-->_Count, $Language->Phrase("DetailCount")));		
		<!--## } ##-->
				$link = "<li><a href=\"#\" data-toggle=\"tab\" data-table=\"<!--##=sDetailTblVar##-->\" data-url=\"" . $url . "\">" . $label . "</a></li>";			
				$links .= $link;
				$detaillnk = ew_JsEncode3("<!--##=sDetailUrl##-->");
				$btngrp .= "<<!--##=sBtnTag##--><!--##=sBtnAttrs##--> title=\"" . $Language->TablePhrase("<!--##=sDetailTblVar##-->", "TblCaption") . "\" onclick=\"window.location='" . $detaillnk . "'\">" . $Language->Phrase("MasterDetailListLink") . "</<!--##=sBtnTag##-->>";
			}
			if ($GLOBALS["<!--##=sDetailPageObj##-->"]->DetailView<!--##=sDetailViewVisible##-->)
				$btngrp .= "<<!--##=sBtnTag##--><!--##=sBtnAttrs##--> title=\"" . ew_HtmlTitle($Language->Phrase("MasterDetailViewLink")) . "\" onclick=\"window.location='" . $this->GetViewUrl(EW_TABLE_SHOW_DETAIL . "=<!--##=sDetailTblVar##-->") . "'\">" . $Language->Phrase("MasterDetailViewLink") . "</<!--##=sBtnTag##-->>";
	<!--## if (MASTERTABLE.TblEdit && bDetailEdit) { ##-->
			if ($GLOBALS["<!--##=sDetailPageObj##-->"]->DetailEdit<!--##=sDetailEditVisible##-->)
				$btngrp .= "<<!--##=sBtnTag##--><!--##=sBtnAttrs##--> title=\"" . ew_HtmlTitle($Language->Phrase("MasterDetailEditLink")) . "\" onclick=\"window.location='" . $this->GetEditUrl(EW_TABLE_SHOW_DETAIL . "=<!--##=sDetailTblVar##-->") . "'\">" . $Language->Phrase("MasterDetailEditLink") . "</<!--##=sBtnTag##-->>";
	<!--## } ##-->
	<!--## if (bDetailCopy) { ##-->
			if ($GLOBALS["<!--##=sDetailPageObj##-->"]->DetailAdd<!--##=sDetailCopyVisible##-->)
				$btngrp .= "<<!--##=sBtnTag##--><!--##=sBtnAttrs##--> title=\"" . ew_HtmlTitle($Language->Phrase("MasterDetailCopyLink")) . "\" onclick=\"window.location='" . $this->GetCopyUrl(EW_TABLE_SHOW_DETAIL . "=<!--##=sDetailTblVar##-->") . "'\">" . $Language->Phrase("MasterDetailCopyLink") . "</<!--##=sBtnTag##-->>";
	<!--## } ##-->
			$btngrp .= "</div>";
			if ($link <> "") {
				$btngrps .= $btngrp;
				$option->Body .= "<div class=\"hide ewPreview\">" . $link . $btngrp . "</div>";
			}
		}
<!--##
			} // End if
			TABLE = MASTERTABLE; // Restore table	
		} // End for
##-->
		<!--## if (bPreviewRow) { ##-->

		// Hide detail items if necessary
		$this->ListOptions->HideDetailItemsForDropDown();

		// Column "preview"
		$option = &$this->ListOptions->GetItem("preview");
		if (!$option) { // Add preview column
			$option = &$this->ListOptions->Add("preview");
			$option->OnLeft = <!--##=ew_Val(bLinkOnLeft)##-->;
			if ($option->OnLeft) {
				$option->MoveTo($this->ListOptions->ItemPos("checkbox") + 1);
			} else {
				$option->MoveTo($this->ListOptions->ItemPos("checkbox"));
			}
			$option->Visible = !($this->Export <> "" || $this->CurrentAction == "gridadd" || $this->CurrentAction == "gridedit");
			$option->ShowInDropDown = FALSE;
			$option->ShowInButtonGroup = FALSE;
		}
		if ($option) {
			$option->Body = "<span class=\"ewPreviewRowBtn icon-expand\"></span>";
			$option->Body .= "<div class=\"hide ewPreview\">" . $links . $btngrps . "</div>";
			if ($option->Visible) $option->Visible = $links <> "";
		}

		<!--## } ##-->
		
		// Column "details" (Multiple details)
		$option = &$this->ListOptions->GetItem("details");
		if ($option) {
			$option->Body .= "<div class=\"hide ewPreview\">" . $links . $btngrps . "</div>";
			if ($option->Visible) $option->Visible = $links <> "";
		}

<!--##
	}	
##-->		
<!--##/session##-->