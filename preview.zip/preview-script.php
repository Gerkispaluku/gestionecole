<?php
<!--##session phpmain##-->

	var $Recordset;
	var $TotalRecs;
	var $RowCnt;
	var $RecCount;
	var $ListOptions; // List options
	var $OtherOptions; // Other options

	//
	// Page main
	//
	function Page_Main() {
		global $Language;

		// Load filter
		$filter = @$_GET["f"];
		$filter = ew_Decrypt($filter);
		if ($filter == "") $filter = "0=1";

		// Set up foreign keys from filter
		$this->SetupForeignKeysFromFilter($filter);

	<!--## if (SYSTEMFUNCTIONS.ServerScriptExist("Table","Recordset_Selecting")) { ##-->
		// Call Recordset Selecting event
		$this->Recordset_Selecting($filter);
	<!--## } ##-->

		// Load recordset
		$filter = $this->ApplyUserIDFilters($filter);
		$this->TotalRecs = 0;
		$this->Recordset = $this->LoadRs($filter);

		if ($this->Recordset) {
			$this->TotalRecs = $this->Recordset->RecordCount();
		<!--## if (SYSTEMFUNCTIONS.ServerScriptExist("Table","Recordset_Selected")) { ##-->
			// Call Recordset Selected event
			$this->Recordset_Selected($this->Recordset);
		<!--## } ##-->
			$this->LoadListRowValues($this->Recordset);
		}
		$this->RenderOtherOptions();
	}

<!--##
	// Set up view link visibility
	sViewVisible = ew_SecurityCheck("View", bSecurityEnabled, bUserTable);
	if (sViewVisible == "") sViewVisible = "TRUE";

	// Set up edit link visibility
	sEditVisible = ew_SecurityCheck("Edit", bSecurityEnabled, bUserTable);
	if (sEditVisible == "") sEditVisible = "TRUE";

	// Set up copy link visibility
	sCopyVisible = ew_SecurityCheck("Add", bSecurityEnabled, bUserTable);
	if (sCopyVisible == "") sCopyVisible = "TRUE";

	// Set up delete link visibility
	sDeleteVisible = ew_SecurityCheck("Delete", bSecurityEnabled, bUserTable);
	if (sDeleteVisible == "") sDeleteVisible = "TRUE";
##-->

	// Set up list options
	function SetupListOptions() {
		global $Security, $Language;

		// Add group option item
		$item = &$this->ListOptions->Add($this->ListOptions->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = <!--##=ew_Val(bLinkOnLeft)##-->;
		$item->Visible = FALSE;

<!--## if (TABLE.TblView) { ##-->
		// "view"
		$item = &$this->ListOptions->Add("view");
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = <!--##=sViewVisible##-->;
		$item->OnLeft = <!--##=ew_Val(bLinkOnLeft)##-->;
<!--## } ##-->

<!--## if (TABLE.TblEdit) { ##-->
		// "edit"
		$item = &$this->ListOptions->Add("edit");
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = <!--##=sEditVisible##-->;
		$item->OnLeft = <!--##=ew_Val(bLinkOnLeft)##-->;
<!--## } ##-->

<!--## if (TABLE.TblCopy && TABLE.TblAdd) { ##-->
		// "copy"
		$item = &$this->ListOptions->Add("copy");
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = <!--##=sCopyVisible##-->;
		$item->OnLeft = <!--##=ew_Val(bLinkOnLeft)##-->;
<!--## } ##-->

<!--## if (TABLE.TblDelete) { ##-->
		// "delete"
		$item = &$this->ListOptions->Add("delete");
		$item->CssStyle = "white-space: nowrap;";
		$item->Visible = <!--##=sDeleteVisible##-->;
		$item->OnLeft = <!--##=ew_Val(bLinkOnLeft)##-->;
<!--## } ##-->

		// Drop down button for ListOptions
		$this->ListOptions->UseDropDownButton = <!--##=ew_Val(bUseDropDownForListOptions)##-->;
		$this->ListOptions->DropDownButtonPhrase = $Language->Phrase("ButtonListOptions");
		$this->ListOptions->UseButtonGroup = <!--##=ew_Val(bUseButtonsForLinks)##-->;
		$this->ListOptions->UseImageAndText = TRUE;
		$this->ListOptions->ButtonClass = "btn-sm"; // Class for button group

<!--## if (SYSTEMFUNCTIONS.ServerScriptExist("Table","ListOptions_Load")) { ##-->
		// Call ListOptions_Load event
		$this->ListOptions_Load();
<!--## } ##-->

		$item = &$this->ListOptions->GetItem($this->ListOptions->GroupOptionName);
		$item->Visible = $this->ListOptions->GroupOptionVisible();

	}

<!--##
	// Set up view link visibility
	sViewVisible = ew_SecurityCheck("View", bSecurityEnabled, bUserTable);
	if (sViewVisible == "") sViewVisible = "TRUE";

	// Set up edit link visibility
	sEditVisible = ew_SecurityCheck("Edit", bSecurityEnabled, bUserTable);
	if (sEditVisible == "") sEditVisible = "TRUE";

	// Set up copy link visibility
	sCopyVisible = ew_SecurityCheck("Add", bSecurityEnabled, bUserTable);
	if (sCopyVisible == "") sCopyVisible = "TRUE";

	// Set up delete link visibility
	sDeleteVisible = ew_SecurityCheck("Delete", bSecurityEnabled, bUserTable);
	if (sDeleteVisible == "") sDeleteVisible = "TRUE";

	if (bInlineDelete)
		sDeleteConfirm = " onclick=\"return ew_Confirm(ewLanguage.Phrase('DeleteConfirmMsg'));\"";
	else
		sDeleteConfirm = "";
##-->

	// Render list options
	function RenderListOptions() {
		global $Security, $Language, $objForm;

		$this->ListOptions->LoadDefault();

		$masterkeyurl = $this->MasterKeyUrl();

	<!--## if (TABLE.TblView) { ##-->
		// "view"
		$oListOpt = &$this->ListOptions->Items["view"];
		if (<!--##=sViewVisible##-->)
			$oListOpt->Body = "<a class=\"ewRowLink ewView\" title=\"" . ew_HtmlTitle(<!--##=sViewLinkCaption##-->) . "\" data-caption=\"" . ew_HtmlTitle(<!--##=sViewLinkCaption##-->) . "\" href=\"" . ew_HtmlEncode($this->GetViewUrl($masterkeyurl)) . "\">" . <!--##=sViewLinkCaption##--> . "</a>";
		else
			$oListOpt->Body = "";
	<!--## } ##-->

	<!--## if (TABLE.TblEdit) { ##-->
		// "edit"
		$oListOpt = &$this->ListOptions->Items["edit"];
		if (<!--##=sEditVisible##-->) {
			$oListOpt->Body = "<a class=\"ewRowLink ewEdit\" title=\"" . ew_HtmlTitle(<!--##=sEditLinkCaption##-->) . "\" data-caption=\"" . ew_HtmlTitle(<!--##=sEditLinkCaption##-->) . "\" href=\"" . ew_HtmlEncode($this->GetEditUrl($masterkeyurl)) . "\">" . <!--##=sEditLinkCaption##--> . "</a>";
		} else {
			$oListOpt->Body = "";
		}
	<!--## } ##-->

	<!--## if (TABLE.TblCopy && TABLE.TblAdd) { ##-->
		// "copy"
		$oListOpt = &$this->ListOptions->Items["copy"];
		if (<!--##=sCopyVisible##-->) {
			$oListOpt->Body = "<a class=\"ewRowLink ewCopy\" title=\"" . ew_HtmlTitle(<!--##=sCopyLinkCaption##-->) . "\" data-caption=\"" . ew_HtmlTitle(<!--##=sCopyLinkCaption##-->) . "\" href=\"" . ew_HtmlEncode($this->GetCopyUrl($masterkeyurl)) . "\">" . <!--##=sCopyLinkCaption##--> . "</a>";
		} else {
			$oListOpt->Body = "";
		}
	<!--## } ##-->

	<!--## if (TABLE.TblDelete) { ##-->
		// "delete"
		$oListOpt = &$this->ListOptions->Items["delete"];
		if (<!--##=sDeleteVisible##-->)
			$oListOpt->Body = "<a class=\"ewRowLink ewDelete\"" . "<!--##=ew_Quote(sDeleteConfirm)##-->" . " title=\"" . ew_HtmlTitle(<!--##=sDeleteLinkCaption##-->) . "\" data-caption=\"" . ew_HtmlTitle(<!--##=sDeleteLinkCaption##-->) . "\" href=\"" . ew_HtmlEncode($this->GetDeleteUrl()) . "\">" . <!--##=sDeleteLinkCaption##--> . "</a>";
		else
			$oListOpt->Body = "";
	<!--## } ##-->

	<!--## if (SYSTEMFUNCTIONS.ServerScriptExist("Table","ListOptions_Rendered")) { ##-->
		// Call ListOptions_Rendered event
		$this->ListOptions_Rendered();
	<!--## } ##-->

	}

	// Set up other options
	function SetupOtherOptions() {
		global $Language, $Security;

		$options = &$this->OtherOptions;

<!--##
	if (TABLE.TblAdd) {
		sAddVisible = ew_SecurityCheck("Add", bSecurityEnabled, bUserTable);
		if (sAddVisible == "") sAddVisible = "TRUE";
##-->
		$option = $options["addedit"];
		$option->UseButtonGroup = <!--##=ew_Val(bUseButtonsForLinks)##-->;

	<!--## if (TABLE.TblAdd) { ##-->
		// Add group option item
		$item = &$option->Add($option->GroupOptionName);
		$item->Body = "";
		$item->OnLeft = <!--##=ew_Val(bLinkOnLeft)##-->;
		$item->Visible = FALSE;

		// Add
		$item = &$option->Add("add");
		$item->Visible = <!--##=sAddVisible##-->;
	<!--## } ##-->

<!--##
	}
##-->

	}

	// Render other options
	function RenderOtherOptions() {
		global $Language, $Security;

		$options = &$this->OtherOptions;

<!--##
	if (TABLE.TblAdd) {
		sAddVisible = ew_SecurityCheck("Add", bSecurityEnabled, bUserTable);
		if (sAddVisible == "") sAddVisible = "TRUE";
##-->
		$option = $options["addedit"];

	<!--## if (TABLE.TblAdd) { ##-->
		// Add
		$item = &$option->GetItem("add");
		$item->Body = "<a class=\"btn btn-default btn-sm ewAddEdit ewAdd\" title=\"" . ew_HtmlTitle($Language->Phrase("AddLink")) . "\" data-caption=\"" . ew_HtmlTitle($Language->Phrase("AddLink")) . "\" href=\"" . ew_HtmlEncode($this->GetAddUrl($this->MasterKeyUrl())) . "\">" . $Language->Phrase("AddLink") . "</a>";
	<!--## } ##-->

<!--##
	}
##-->

	}

	// Get master foreign key url
	function MasterKeyUrl() {
		$mastertblvar = @$_GET["t"];
		$url = "";
	<!--##
		// Build master/detail information
		for (var i = 0, len = arMasterTables.length; i < len; i++) {
			var MasterDetail = goAllMasDets[arMasterTables[i].index];
			MASTERTABLE = ew_GetTblObj(MasterDetail.MasterTable);
			if (MASTERTABLE.TblGen) {
				sMasterTblVar = MASTERTABLE.TblVar;
	##-->
		if ($mastertblvar == "<!--##=sMasterTblVar##-->") {
	<!--##
				sDetailUrl = "\" . EW_TABLE_SHOW_MASTER . \"=" + sMasterTblVar;
				sQry = "";
				for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
					MASTERFIELD = ew_GetFldObj(MASTERTABLE, MasterDetail.Rels[j].MasterField);
					sMasterFldParm = MASTERFIELD.FldParm;
					sQry += "&fk_" + sMasterFldParm + "=";
					DETAILFIELD = ew_GetFldObj(TABLE, MasterDetail.Rels[j].DetailField);
					sDetailFldParm = DETAILFIELD.FldParm;
					qv = "this->" + sDetailFldParm + "->QueryStringValue";
					if (ew_GetFieldType(DETAILFIELD.FldType) == 2)
						sQry += "\" . urlencode(ew_UnFormatDateTime($" + qv + ", 0)) . \"";
					else
						sQry += "\" . urlencode(strval($" + qv + ")) . \"";
				} // MasterDetailField
				sDetailUrl += sQry;
	##-->
			$url = "<!--##=sDetailUrl##-->";
		}
	<!--##
			}
		} // MasterDetail
	##-->
		return $url;
	}

	// Set up foreign keys from filter
	function SetupForeignKeysFromFilter($f) {
		$mastertblvar = @$_GET["t"];
	<!--##
		// Build master/detail information
		for (var i = 0, len = arMasterTables.length; i < len; i++) {
			var MasterDetail = goAllMasDets[arMasterTables[i].index];
			MASTERTABLE = ew_GetTblObj(MasterDetail.MasterTable);
			if (MASTERTABLE.TblGen) {
				sMasterTblVar = MASTERTABLE.TblVar;
	##-->
		if ($mastertblvar == "<!--##=sMasterTblVar##-->") {
	<!--##
				for (var j = 0, cnt = MasterDetail.Rels.length; j < cnt; j++) {
					MASTERFIELD = ew_GetFldObj(MASTERTABLE, MasterDetail.Rels[j].MasterField);
					sMasterFldParm = MASTERFIELD.FldParm;
					DETAILFIELD = ew_GetFldObj(TABLE, MasterDetail.Rels[j].DetailField);
					sDetailFldParm = DETAILFIELD.FldParm;
					sDetailFldExpression = ew_FieldSqlName(DETAILFIELD, sTblDbId);
	##-->
			$find = "<!--##=ew_Quote(sDetailFldExpression)##-->="; 
			$x = strpos($f, $find);
			if ($x !== FALSE) {
				$x += strlen($find);
		<!--## if (j < cnt-1) { ##-->
				$y = strpos($f, " AND ", $x);
				if ($y !== FALSE)
					$val = substr($f, $x, $y-$x);
				else
					$val = "";
		<!--## } else { ##-->
				$val = substr($f, $x);
		<!--## } ##-->
				$val = $this->UnquoteValue($val, "<!--##=ew_Quote(sTblDbId)##-->");
 				$this-><!--##=sDetailFldParm##-->->setQueryStringValue($val);
			}
	<!--##
				} // MasterDetailField
	##-->
		}
	<!--##
			}
		} // MasterDetail
	##-->
	}

	// Unquote value
	function UnquoteValue($val, $dbid) {
		if (substr($val,0,1) == "'" && substr($val,strlen($val)-1) == "'") {
			if (ew_GetConnectionType($dbid) == "MYSQL")
				return stripslashes(substr($val, 1, strlen($val)-2));
			else
				return str_replace("''", "'", substr($val, 1, strlen($val)-2));
		} else {
			return $val;
		}
	}

<!--##/session##-->
?>

<!--##session htmtable##-->
<!--##include phpcommon.php/header-message##-->
<?php if ($<!--##=sPageObj##-->->TotalRecs > 0) { ?>
<div class="ewGrid">
<table<!--##=ewCSSTableClass##-->>
	<thead><!-- Table header -->
		<tr<!--##=ewCSSTableHeaderClass##-->>
	
<?php
// Render list options
$<!--##=sPageObj##-->->RenderListOptions();

// Render list options (header, left)
$<!--##=sPageObj##-->->ListOptions->Render("header", "left");
?>

		<!--##
			for (var i = 0; i < nFldCount; i++) {
				if (ew_LoadField(arFlds[i])) {
		##-->
<?php if ($<!--##=gsFldObj##-->->Visible) { // <!--##=gsFldName##--> ?>
			<th<!--##=ew_FieldHeaderAttributes(FIELD)##-->><?php echo $<!--##=gsFldObj##-->->FldCaption() ?></th>
<?php } ?>
		<!--##
				}
			} // Field
		##-->	

<?php
// Render list options (header, right)
$<!--##=sPageObj##-->->ListOptions->Render("header", "right");
?>

		</tr>
	</thead>
	<tbody><!-- Table body -->
<?php
$<!--##=sPageObj##-->->RecCount = 0;
$<!--##=sPageObj##-->->RowCnt = 0;

while ($<!--##=sPageObj##-->->Recordset && !$<!--##=sPageObj##-->->Recordset->EOF) {

	// Init row class and style
	$<!--##=sPageObj##-->->RecCount++;
	$<!--##=sPageObj##-->->RowCnt++;
	$<!--##=sPageObj##-->->CssStyle = "";

	$<!--##=sPageObj##-->->LoadListRowValues($<!--##=sPageObj##-->->Recordset);
<!--## if (SYSTEMFUNCTIONS.IsAggregate()) { ##-->
	$<!--##=sPageObj##-->->AggregateListRowValues(); // Aggregate row values
<!--## } ##-->

	// Render row
	$<!--##=sPageObj##-->->RowType = EW_ROWTYPE_PREVIEW; // Preview record
	$<!--##=sPageObj##-->->ResetAttrs();
	$<!--##=sPageObj##-->->RenderListRow();

	// Render list options
	$<!--##=sPageObj##-->->RenderListOptions();
?>
	<tr<?php echo $<!--##=sPageObj##-->->RowAttributes() ?>>

<?php
// Render list options (body, left)
$<!--##=sPageObj##-->->ListOptions->Render("body", "left", $<!--##=sPageObj##-->->RowCnt);
?>

	<!--##
		for (var i = 0; i < nFldCount; i++) {
			if (ew_LoadField(arFlds[i])) {
	##-->
<?php if ($<!--##=gsFldObj##-->->Visible) { // <!--##=FIELD.FldName##--> ?>
		<!-- <!--##=FIELD.FldName##--> -->
		<td<?php echo $<!--##=gsFldObj##-->->CellAttributes() ?>><!--##=SYSTEMFUNCTIONS.FieldView()##--></td>
<?php } ?>
	<!--##
			}
		}
	##-->

<?php
// Render list options (body, right)
$<!--##=sPageObj##-->->ListOptions->Render("body", "right", $<!--##=sPageObj##-->->RowCnt);
?>

	</tr>

<?php
	$<!--##=sPageObj##-->->Recordset->MoveNext();
}
?>
	</tbody>
<!--## if (SYSTEMFUNCTIONS.IsAggregate()) { ##-->
<?php
	// Render aggregate row
	$<!--##=sPageObj##-->->AggregateListRow(); // Prepare aggregate row

	// Render list options
	$<!--##=sPageObj##-->->RenderListOptions();

?>
	<tfoot><!-- Table footer -->
	<tr<!--##=ewCSSTableFooterClass##-->>

<?php
// Render list options (footer, left)
$<!--##=sPageObj##-->->ListOptions->Render("footer", "left");
?>

	<!--##
		for (var i = 0; i < nFldCount; i++) {
			if (ew_LoadField(arFlds[i])) {
	##-->
<?php if ($<!--##=gsFldObj##-->->Visible) { // <!--##=gsFldName##--> ?>
		<!-- <!--##=gsFldName##--> -->
		<td>
	<!--## if (FIELD.FldAggregate != "") { ##-->
		<!--##=SYSTEMFUNCTIONS.FieldAggregate()##-->
	<!--## } else { ##-->
		&nbsp;
	<!--## } ##-->
		</td>
<?php } ?>
	<!--##
			}
		} // Field
	##-->

<?php
// Render list options (footer, right)
$<!--##=sPageObj##-->->ListOptions->Render("footer", "right");
?>

	</tr>
	</tfoot>
<!--## } ##-->
</table>
</div>
<?php } ?>
<div class="ewPreviewLowerPanel">
<?php if ($<!--##=sPageObj##-->->TotalRecs > 0) { ?>
<div class="ewDetailCount"><?php echo $<!--##=sPageObj##-->->TotalRecs ?>&nbsp;<?php echo $Language->Phrase("Record") ?></div>
<?php } else { ?>
<div class="ewDetailCount"><!--##@NoRecord##--></div>
<?php } ?>
<div class="ewPreviewOtherOptions">
<?php
	foreach ($<!--##=sPageObj##-->->OtherOptions as &$option)
		$option->Render("body");
?>
</div>
<div class="clearfix"></div>
</div>
<!--##include phpcommon.php/footer-message##-->
<?php
if ($<!--##=sPageObj##-->->Recordset)
	$<!--##=sPageObj##-->->Recordset->Close();

// Output
$content = ob_get_contents();
ob_end_clean();
echo ew_ConvertToUtf8($content);
?>
<!--##/session##-->

<?php
<!--##session phpevents##-->
	<!--##~SYSTEMFUNCTIONS.GetServerScript("Table","ListOptions_Load")##-->
	<!--##~SYSTEMFUNCTIONS.GetServerScript("Table","ListOptions_Rendered")##-->
<!--##/session##-->
?>