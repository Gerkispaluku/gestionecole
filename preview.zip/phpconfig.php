<!--##session preview_config##-->
<!--##
	var bUseDetailPreview = false;
	var bPreviewOverlay = false;
	var bPreviewRow = false;
	var bSingleRow = false;
	var sPreviewRowColor = "#FFFFFF";
	var sExtName = "Preview";
	var EXT = ew_GetExtObj(sExtName);
	if (EXT && EXT.Enabled) {
		var EXT_TABLE = ew_GetExtTbl(sExtName, TABLE.TblName);
		if (EXT_TABLE) {
			bUseDetailPreview = ew_GetExtPrp(EXT_TABLE.Properties, "UseDetailPreview");
			bPreviewOverlay = ew_GetExtPrp(EXT_TABLE.Properties, "PreviewOverlay");
			bPreviewRow = ew_GetExtPrp(EXT_TABLE.Properties, "PreviewRow");
			bSingleRow = ew_GetExtPrp(EXT_TABLE.Properties, "SingleRow");
			sPreviewRowColor = ew_GetExtPrp(EXT_TABLE.Properties, "PreviewRowColor") || "#FFFFFF";
		}
	}

	if (TABLE.TblUseGlobal && PROJ.RecPerRow >= 1 || !TABLE.TblUseGlobal && TABLE.TblRecPerRow >= 1)
		bPreviewRow = false;

	var bGenPreview = (CTRL.CtrlID == "list" && bUseDetailPreview);
		
	sTblVar = gsTblVar;
##-->
<!--##/session##-->
