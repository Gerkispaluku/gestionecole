/**
 * Detail Preview Extension
 * @license (C) 2017 e.World Technology Ltd.
 */
var EW_LOADING_HTML = "<div class='ewSpinner'><div></div></div> " + ewLanguage.Phrase("Loading");
var EW_PREVIEW_BUTTON_SELECTOR = ".ewPreviewRowBtn";

// Add preview row
function ew_AddRowToTable(r) {
	var $ = jQuery, $r = $(r), row, $cell, cspan = 0;
	var $tb = $r.closest("tbody");
	if (EW_PREVIEW_SINGLE_ROW)
		$tb.find("tr." + EW_TABLE_PREVIEW_ROW_CLASSNAME).remove();
	$(r.cells).each(function() { cspan += this.colSpan; });
	var $sr = $r.nextAll("tr[data-rowindex!=" + $r.data("rowindex") + "]").first();
	if ($sr.hasClass(EW_TABLE_PREVIEW_ROW_CLASSNAME)) { // Preview row exists
		return $sr[0];
	} else if (row = $tb[0].insertRow(($sr[0]) ? $sr[0].sectionRowIndex : -1)) { // Insert a new row
		$(row).addClass(EW_TABLE_PREVIEW_ROW_CLASSNAME);
		$cell = $(row.insertCell(0)).addClass(EW_TABLE_LAST_COL_CLASSNAME).prop("colSpan", cspan);
	}
	return row;
}

// Show detail preview by table row expansion
function ew_ShowDetails(e) {
	var $ = jQuery, $el = $(this), isRow = $el.is("tr[data-rowindex]"),
		$r = (isRow) ? $el : $el.closest("tr[data-rowindex]"), $tbl = $r.closest("table");
	if (!$r[0])
		return;
	if (!$r.data("preview")) {
		var row = ew_AddRowToTable($r[0]);
		var $cell = $(row.cells[0]);
		var	$content = $r.find("[class$=_preview] div.ewPreview");
		$cell.empty(); // Note: do not chain
		$cell.append($("#ewPreview").contents().clone()) // Append the contents
			.find(".nav-tabs").append($content.find("li:has([data-toggle='tab'])").clone(true)) // Append tabs
			.find("[data-toggle='tab']").attr("data-target", "#" + $cell.find(".tab-pane").attr("id", ew_Random()).attr("id")) // Setup tabs and tab pane
			.first().tab('show'); // Show the first tab
		((EW_PREVIEW_SINGLE_ROW) ? $tbl : $r).find(EW_PREVIEW_BUTTON_SELECTOR).addClass("icon-expand").removeClass("icon-collapse");
		$r.data("preview", true).find(EW_PREVIEW_BUTTON_SELECTOR).addClass("icon-collapse").removeClass("icon-expand");
	} else {
		var $sr = $r.nextAll("tr[data-rowindex!='" + $r.data("rowindex") + "']").first();
		if ($sr.hasClass(EW_TABLE_PREVIEW_ROW_CLASSNAME))
			$sr.remove();
		$r.data("preview", false).find(EW_PREVIEW_BUTTON_SELECTOR).addClass("icon-expand").removeClass("icon-collapse");
	}
	ew_SetupTable(-1, $tbl[0], true);
}

// Setup preview overlay
function ew_Detail(i, el) {
	var $ = jQuery, $this = $(el), $parent = $this.closest(".ewListOptionBody"),
		dir = $this.data("placement") || EW_PREVIEW_PLACEMENT, // dir = "left|right"
		$ul = $parent.find(".dropdown-menu"), $div = $parent.find(".btn-group");
	$ul.mouseenter(function(e) { e.stopPropagation(); }); // Inside dropdown
	if ($div[0]) { // Button group
		if (dir == "right") // Right popover
			$ul.addClass("pull-right"); // Right dropdown
		$this = $div; // Create popover for button group (not the element)
	}
	if ($this.data("bs.popover"))
		return;
	$this.popover({
		html: true,
		delay: { show: 100, hide: 250 },
		placement: dir,
		trigger: "hover",
		container: $("#ewTooltip")[0],
		content: EW_LOADING_HTML
	}).on("show.bs.popover", function(e) {
		$(".popover.ewPreviewOverlay").hide();
		$this.data("bs.popover").tip().css("opacity", 0); // Hide first, to be shown in "shown" event
	}).on("shown.bs.popover", function(e) {
		var $tip = $this.data("bs.popover").tip().css({ "min-width": "200px", "max-width": "1000px" }); // Set min/max width and show
		$tip.find(".popover-content").html($("#ewPreview").html()); // Add the preview template
		$tip.find(".nav-tabs").append($parent.find("li:has([data-toggle='tab'])").clone(true)); // Append tabs
		$tip.find("[data-toggle='tab']").attr("data-target", "#" + $tip.find(".tab-pane").attr("id", ew_Random()).attr("id")) // Setup tabs
			.data("$element", $this).first().tab('show'); // Show the first tab
		ew_MoveTip($this); // Move
		$tip.fadeTo(0, 1).addClass("ewPreviewOverlay"); // Show
	}).data("bs.popover").tip().mouseenter(function(e) {
		clearTimeout($this.data("bs.popover").timeout);
	}).mouseleave(function(e) {
		var po = $this.data("bs.popover");
		if (po.tip().html().indexOf(EW_LOADING_HTML) > -1) // Loading
			return;
		po.timeout = setTimeout(function() {
		    po.hide.call(po);
	    }, po.options.delay.hide);
	});
}

function ew_MoveTip($el) {
	var $ = jQuery, dir = $el.data("placement") || EW_PREVIEW_PLACEMENT;
	if (dir != "left" && dir != "right")
		return;
	var $document = $(document), $body = $(document.body), $tip = $el.data("bs.popover").tip(),
		w = $tip.width(), tp = $tip.offset(), $parent = $el.parent();
		bottom = $document.scrollTop() + $body.outerHeight() - $tip.outerHeight();
	if ($parent.hasClass("btn-group")) { // e.target is under a button group
		$el = $parent;
		$parent = $el.parent();
	}
	var ep = $el.offset();
	tp.top = ep.top + $el.height() / 2 - $tip.height() / 2;
	tp.top = Math.max($document.scrollTop(), Math.min(bottom, tp.top));
	$tip.css("top", tp.top + "px"); // Move
	//$tip.find("." + EW_TABLE_CLASSNAME).each(ew_SetupTable);
	if (dir == "right" && $el.is(".btn-group"))
		$tip.css("left", ep.left + $el.width());
	var $arrow = $tip.find(".arrow");
	if (dir == "left") {
		left = ep.left - $tip.outerWidth() - $arrow.width();
		$tip.css("left", left);
	}
	var top = ep.top - tp.top + $el.height() / 2 - $arrow.height();
	var mintop = (parseInt($tip.css("border-top-left-radius"), 10) || 6) - parseInt($arrow.css("margin-top"), 10);
	var maxtop = $tip.height() - mintop - $arrow.height();
	$arrow.css("top", Math.max(mintop, Math.min(top, maxtop)) + "px");
}

// Tab "show" event
function ew_TabShow(e) {
	var $ = jQuery, $el = $(e.target), url = $el.data("url"), table = $el.data("table"), $target = $($el.attr("data-target"));
	if (url && $target[0]) {
		$target.empty().html(EW_LOADING_HTML);
		$.get(url, function(data) {
			$target.empty().html(data) // Append the detail records
				.append($("div[data-table='" + table + "'][data-url='" + url + "']:first").clone()); // Append the buttons
			$(document).trigger("preview", [{ "$tabpane": $target }]);
			if ($el.data("$element")) // Overlay
				ew_MoveTip($el.data("$element"))
		});
	}
}

// Default preview event
function ew_Preview(e, args) {
	var $tabpane = args.$tabpane; // Tab pane
	$tabpane.find("table." + EW_TABLE_CLASSNAME).each(ew_SetupTable); // Setup the table
	//$(".ewIcon").closest("a, button").add(".ewTooltip").tooltip({ container: "body", placement: "bottom", trigger: "hover" }); // Init icon tooltip
	ew_InitIcons();
	$tabpane.find("a.ewTooltipLink").each(ew_Tooltip); // Setup tooltip
	$(".ewLightbox").each(function() {
		var $this = $(this);
		$this.colorbox($.extend({rel: $this.data("rel")}, ewLightboxSettings));
	}); // Init lightbox
}
jQuery(document).on("preview", ew_Preview);

// Setup events and tab links
jQuery(function($) {
	if (EW_PREVIEW_OVERLAY) // PreviewOverlay
		$("div.ewPreview").each(function() {
			$(this).parent().find("[data-action='view'],[data-action='list']").each(ew_Detail);
		});
	// PreviewRow
	$(EW_PREVIEW_BUTTON_SELECTOR).click(ew_ShowDetails); // Add onclick event to images
	//$(EW_PREVIEW_BUTTON_SELECTOR).off("click", ew_ShowDetails); // Remove onclick event from images
	//$("tr[data-rowindex]").click(ew_ShowDetails); // Add onclick event to rows
	$("div.ewPreview [data-toggle='tab']").on("show.bs.tab", ew_TabShow);
});